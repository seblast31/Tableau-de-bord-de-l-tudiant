<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../sources/polytech.png">

    <title>Intranet Polytech Paris-Sud - Vue Message</title>

    <!-- Bootstrap core CSS -->
    <link href="../../sources/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../dashboard.css" rel="stylesheet">
  </head>

  <body>
    <nav class="navbar navbar-expand-md navbar-inverse fixed-top bg-inverse">
      <a class="navbar-brand" href="../index.php">Mon compte</a>
      <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="../Calendrier/index.html">Agenda </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="notes.html">Notes</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="Vuemes2.php">Messagerie <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="">Documents</a>
          </li>
        </ul>
        <form class="form-inline mt-2 mt-md-0">
          <input class="form-control mr-sm-2" type="text" placeholder="documents,email...">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Recherche</button>
        </form>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-sm-3 col-md-2 d-none d-sm-block bg-faded sidebar">
          <ul class="nav nav-pills flex-column">
            <li class="nav-item">
              <a class="nav-link " href="Vuemes2.php">Messages Reçus</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="">Messages envoyés <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="">Brouillons</a>
            </li>
          </ul>
           <ul class="nav nav-pills flex-column">
         <li class="nav-item">
        <hr> <div class="styled-select blue semi-square">
            <select>
                <option>Mes canaux d'intêrets</option>
                <option>direction de communication</option>
                <option>projet tab de bord</option>
                <option>offres de stage</option>
            </select>
        </div>
        </li>
          </ul>
          <ul class="nav nav-pills flex-column">
            <li class="nav-item">
              <a class="nav-link" href="EcrireNewMessage.php">Ecrire un nouveau message</a>
            </li>
          </ul>

         
        </nav>

        <main class="col-sm-9 offset-sm-3 col-md-10 offset-md-2 pt-3">
          <h1>Erradi Ismail</h1>

          <section class="row text-center placeholders">
            <div class="col-6 col-sm-3 placeholder">
              <img src="../../sources/promo.jpg" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4>Promo</h4>
              <div class="text-muted">2018</div>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="../../sources/mat.jpg" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4>Formation</h4>
              <span class="text-muted">Informatique</span>
            </div>
          </section>

          <h2>Messages Envoyés</h2>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
              <tbody>
                <tr>
                  <th>Objet</th>
                  <th> À  </th>
                  <th>Date d'envoie</th>
                </tr>
                </tbody>
              </thead>
              <thead>
                <tr>
                  <td> Projet info </td>
                  <td>Sebastien</td>
                  <td>20/03/2018</td>
                </tr>
              </thead>

            </table>
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../sources/jquery.min.js"><\/script>')</script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="../../sources/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../sources/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
